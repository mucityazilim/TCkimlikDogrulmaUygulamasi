#include "Kimlik.h"
#include <iostream>
#include <cstring>
#include <conio.h>
#include <stdlib.h>


using namespace std; 

// TC kimlik do�rulama kurallar�



bool Kimlik:: birinKural()
{
	// 1. kural: ilk 10 rakam�n toplam�n�n birler basama��ndaki rakam 11. rakam� vermektedir
	ilkOnToplami =0; 			
	for( int i=0; i<10; i++ ) 
		ilkOnToplami += intTCNo[i]; 
	
	if( ( ilkOnToplami %10 )  == intTCNo[10]  )  // 10. indis = 11. rakam
	return true;  
	else
	return false; 
		
 } 
bool Kimlik:: ikinciKural()
{
	// 2. kural:  1,3,5,7,9. rakamlar�n toplam�n�n 7 kat� ile 
	//   2, 4, 6, 8. rakamlar�n toplam�n�n 9 kat�n�n toplam�n�n birler basama�� 10. rakam� vermelidir

	tekRakamToplami =0; 
	ciftRakamToplami=0; // sonradan ekledim			
	for( int i=0; i<9; i+=2 ) 
		tekRakamToplami += intTCNo[i];
		
	for( int i=1; i<8; i+=2 ) 
		ciftRakamToplami += intTCNo[i];
	
	int toplam= ( tekRakamToplami * 7 ) + ( ciftRakamToplami *9 )  ; 
	
	if( ( toplam %10 )  == intTCNo[9]  )  // 9. indis = 10. rakam
	return true;  
	else
	return false; 
}

bool Kimlik:: ucuncuKural()
{
	// 3. Kural.  1,3,5,7,9. rakamlar�n toplam�n�n 8 kat�n�n birler basama��ndaki rakam 11. rakam� vermelidir 
	
	
	int toplam= ( tekRakamToplami * 8 )   ; 
	
	if( ( toplam %10 )  == intTCNo[10]  )  // 10. indis = 11. rakam
	return true;  
	else
	return false; 	
	
}
void  Kimlik:: inputAl() 
{
	cout<<"TC No : "; cin>>strTCNo; 
	if( strlen(strTCNo ) != 11 ) 
		cout<<"Hatali TC Kimlik Numarasi girdiniz !!! "<< endl; 
	else 
	{
		sonuc= true; 
		
		for( int i=0; i<11; i++ ) 
		{
			intTCNo[i]= strTCNo[i] - 48 ; //  
		}
		
		
		if(  ! birinKural()  ) 
		sonuc= false; 
		else if(  ! ikinciKural()  ) 
		sonuc= false; 
		else if(  ! ucuncuKural()  ) 
		sonuc= false; 
		
		system("cls") ; 
		
 		if( sonuc )
		cout<<"TC Kimlik Numarasi Dogrulandi"<< endl; 
		else 
		cout<<"TC Kimlik Numarasi Dogrulanamadi !!! "<< endl;
		
		system("pause") ; 
			
	}	
	
	
} 
  
void Kimlik:: menu()
{
	int secim; 
	while ( true )
	{
		
		cout<<"\nTC Kimlik No Kontrol Uygulamasi "<< endl<< endl; 
		cout<<"[1] TCNo Girisi "<< endl; 
		cout<<"[0] Programi sonlandir...  "<< endl;
		cout<<"Seciminiz :  ";  cin>>secim; 
		
		if( secim== 0 )
		{
			cout<<"Programi sonlandirdiniz..."<< endl; 
			 break; 
		}
		else if( secim == 1 ) 
		inputAl(); 
		else 
		cout<<"Hatali Secim Yaptiniz !!! "<< endl; 	
		
	} 
	
}


