#ifndef KIMLIK_H
#define KIMLIK_H

class Kimlik
{
	private: 
	char strTCNo[12];
	int intTCNo[11]; 
	bool sonuc; 
	int ilkOnToplami; 
	int tekRakamToplami; 
	int ciftRakamToplami;
	bool birinKural(); 
	bool ikinciKural(); 
	bool ucuncuKural(); 
	void inputAl() ; 
	public: 
	void menu(); 

};

#endif
