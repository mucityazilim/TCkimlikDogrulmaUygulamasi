#include <iostream>
#include "Kimlik.h"

using namespace std; 


int main(int argc, char** argv) {

	Kimlik nes; 
	nes.menu() ; 	
	
	
	
	return 0;
}
